package com.zicarelli.restdemo;





import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;


/**
 *
 * @author Pierfrancesco
 */
public class Student {
    
    private long id;
    private String firstName;
    private String lastName;
    private String birthDate;
    private List<String> grades; //ho considerato di utilizzare una lista per l'elenco dei voti
/*
public Student() {
    this.grades=new ArrayList();
}
   */ 
    public Student(String firstName, String lastName, String birthDate, List<String> grades) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.birthDate = birthDate;
        this.grades = grades;
    }
    
    public int age() { //ritengo di ricevere la data in formato italiano (giorno/mese/anno)
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd/MM/yyyy", Locale.ITALIAN);
        LocalDate nascita = LocalDate.parse(this.birthDate,formatter);
        LocalDate oggi=LocalDate.now();
        Period period = Period.between(oggi, nascita);
        int diff=Math.abs(period.getYears());
        return diff;
   
    }

    public double avg_grades() {
        double somma=0;
        int count=0;
        for(String voto: this.grades) {
            int voto_num=Integer.parseInt(voto);
            somma +=voto_num;
            count++;
        }
        if (count==0)
            return 0;
        else return somma/((double) count);
        
    }

    public String getFirstName() {
        return firstName;
    }
    
    public void setFirstName(String first) {
        this.firstName=first;
    }

    public String getLastName() {
        return lastName;
    }
    
    public void setLastName(String last) {
        this.lastName=last;
    }
    
    public String getBirthDate() {
        return birthDate;
    }
    
    public void setBirthDate(String birth) {
        this.birthDate=birth;
    }
    
    public void addGrade(String g) {
        if (this.grades==null)
            this.grades=new ArrayList<String>();
        this.grades.add(g);
    }
    public void setGrades(List<String> list){
        this.grades=list;
    }
    
    public List<String> getGrades() {
        ArrayList<String> nuova=new ArrayList(this.grades);
        return nuova;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }
    
    public String toString() {
        StringBuilder sb=new StringBuilder();
        sb.append("[");
        this.grades.forEach(g -> {sb.append(g); sb.append(",");});
        sb.append("]");
        return this.firstName+" "+this.lastName+" "+this.birthDate+" "+sb.toString();
    }
    
    
    
}


