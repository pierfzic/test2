
package com.zicarelli.restdemo;

import java.util.ArrayList;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/**
 *
 * @author Pierfrancesco
 */
@RestController
@RequestMapping("/fase3")
public class Controllore {
    
    private ArrayList<Student> lista;

    public Controllore() {
        this.lista=new ArrayList();
    }
    
    
    
    @GetMapping("/getall")
    public String tutti() {
        StringBuilder sb=new StringBuilder();
        
        lista.forEach(s -> {
            sb.append(s.toString());
            sb.append("<br>\n");
       });
       sb.append("\n");
       return sb.toString();
    }
    
    
    @PostMapping(value="/insert", consumes=MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    public String secondo(@RequestParam("first") String first, @RequestParam("last") String last, @RequestParam("birth") String birth, @RequestParam("grade") String grade) {
       StringBuilder sb=new StringBuilder();
       sb.append("Ho inserito: ");
       sb.append(first);
       sb.append(" ");
       sb.append(last);
       sb.append(" ");
       sb.append(birth);
       
       Student s=new Student(first,last,birth,new ArrayList<String>());
       s.addGrade(grade);
       this.lista.add(s);
       return sb.toString();
       
       
    }
}
