Il servizio è in ascolto 

- per le chiamate GET all'indirizzo http://localhost:8080/fase3/getall
e risponde con una lista degli studenti gia' inseriti

- per le chiamate POST all'indirizzo  http://localhost:8080/fase3/insert
e risponde con il messaggio "Ho inserito: ...."

Provato con NetBeans 12.5 e plugin NB Spring

Esempio di output con cURL:

C:\Program Files\NetBeans-14\netbeans\bin>curl -X POST -d "first=Luigi&last=Marcone&birth=01/04/2000&grade=30" http://localhost:8080/fase3/insert
Ho inserito: Luigi Marcone 01/04/2000
C:\Program Files\NetBeans-14\netbeans\bin>curl -X POST -d "first=Maria&last=Novello&birth=13/07/1990&grade=27" http://localhost:8080/fase3/insert
Ho inserito: Maria Novello 13/07/1990
C:\Program Files\NetBeans-14\netbeans\bin>curl  http://localhost:8080/fase3/getall
Luigi Marcone 01/04/2000 [30,]<br>
Maria Novello 13/07/1990 [27,]<br>
